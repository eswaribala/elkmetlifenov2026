import logging
import os

from flask import Flask, jsonify, request
from elasticapm.contrib.flask import ElasticAPM

app = Flask(__name__)
apm = ElasticAPM(app)

# Import the HTTP library after APM is initialized.
import requests
import ecs_logging

log = logging.getLogger("order-service")
log.setLevel(logging.INFO)
handler = logging.FileHandler("/var/log/apm-lab/orders.json")
handler.setFormatter(ecs_logging.StdlibFormatter())
log.addHandler(handler)

@app.get("/health")
def health():
    return jsonify(status="healthy", service="order-service")

@app.get("/purchase")
def purchase():
    mode = request.args.get("mode", "normal")
    log.info("Purchase requested: mode=%s", mode)
    response = requests.get(
        "http://127.0.0.1:5051/charge",
        params={"mode": mode},
        timeout=6,
    )
    if not response.ok:
        log.error("Payment failed: status=%s", response.status_code)
        raise RuntimeError("Payment service returned an error")
    log.info("Purchase completed")
    return jsonify(status="ok", payment=response.json())

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5050, debug=False, use_reloader=False)
