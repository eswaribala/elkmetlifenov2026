import logging
import time

import ecs_logging
import elasticapm
from elasticapm.contrib.flask import ElasticAPM
from flask import Flask, jsonify, request

app = Flask(__name__)
apm = ElasticAPM(app)

log = logging.getLogger("payment-service")
log.setLevel(logging.INFO)
handler = logging.FileHandler("/var/log/apm-lab/payments.json")
handler.setFormatter(ecs_logging.StdlibFormatter())
log.addHandler(handler)

@app.get("/health")
def health():
    return jsonify(status="healthy", service="payment-service")

@app.get("/charge")
def charge():
    mode = request.args.get("mode", "normal")
    log.info("Charging request: mode=%s", mode)
    with elasticapm.capture_span(
        "validate-inventory", span_type="custom",
        span_subtype="inventory", span_action="validate"
    ):
        time.sleep(1.5 if mode == "slow" else 0.04)
    if mode == "fail":
        log.error("Simulated payment failure")
        raise RuntimeError("Simulated payment failure for training")
    log.info("Charge completed")
    return jsonify(status="accepted", amount=25)

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5051, debug=False, use_reloader=False)
